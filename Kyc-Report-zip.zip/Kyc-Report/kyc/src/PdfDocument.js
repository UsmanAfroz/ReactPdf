import React from 'react'
import './index.css';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import CancelIcon from '@mui/icons-material/Cancel';
import SyncAltIcon from '@mui/icons-material/SyncAlt';
import purpleQr from "./purpleQr.png";



function PdfDocument() {
  return (

    <div>

    <div className="info-container">

        <div className="info-header-1">
          <h3>Invoice Information</h3>

        </div>

        <div className="top-section">
          <div className="invoice-details">

            <div className="items">
              <h6 >Invoice</h6>
              <p>INV-02</p>
            </div>

            <div className="items">
              <h6>Status</h6>
              <p>Paid</p>
            </div>

            <div className="items">

              <h6>Acknowledged</h6>
              <p>No</p>
            </div>

            <div className="items">

              <h6>Payment Type</h6>
              <p>Cash</p>
            </div>

            <div className="items">

              <h6>Invoice Amount</h6>
              <p>67800</p>
            </div>

          </div>

          <div className="qr-code">
            <img className="qr-img" src={purpleQr} alt="qrCode" />
          </div>


        </div>


        <div className="infoPara">

          <div className="senderInfo">
            <h2>Sender Information</h2>

            <div className="info-item">
              <span className="label">Name:</span>
              <span className="value">sjd k</span>
            </div>
            <div className="info-item">
              <span className="label">Email:</span>
              <span className="value">im4400@mailinator.com</span>
            </div>
            <div className="info-item">
              <span className="label">Mobile Number:</span>
              <span className="value">+924981472897</span>
            </div>
            <div className="info-item">
              <span className="label">Business Name:</span>
              <span className="value">as</span>
            </div>
            <div className="info-item">
              <span className="label">Profession:</span>
              <span className="value">Entertainment</span>
            </div>
            <div className="info-item">
              <span className="label">City:</span>
              <span className="value">Faisalabad</span>
            </div>
          </div>

          <div className='vl'></div>

          <div className="receiverInfo">


            <h2>Receiver Information</h2>
            <div className="info-item">
              <span className="label">Name:</span>
              <span className="value">ajskajs111 jasas22</span>
            </div>
            <div className="info-item">
              <span className="label">Email:</span>
              <span className="value">im2021@mailinator.com</span>
            </div>
            <div className="info-item">
              <span className="label">Mobile Number: </span>
              <span className="value">+971327362736723</span>
            </div>
            <div className="info-item">
              <span className="label">Business Name: </span>
              <span className="value">jahsajs</span>
            </div>
            <div className="info-item">
              <span className="label">Profession:</span>
              <span className="value">Education</span>
            </div>
            <div className="info-item">
              <span className="label">City:</span>
              <span className="value">N/A</span>
            </div>
          </div>
        </div>

      </div>


      {/* Section 2 */}

      <div className="section-2">

        <div className="info-header-2">
          <h3>Business Relation</h3>

        </div>

        <table className="invoice-table">
          <thead>
            <tr>
              <th className="bold">Series</th>
              <th className="bold">3 Months</th>
              <th className="bold">6 Months</th>
              <th className="bold">12 Months</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td >Invoice Amount</td>
              <td>100</td>
              <td>200</td>
              <td>400</td>
            </tr>
            <tr>
              <td >Invoice Count</td>
              <td>6</td>
              <td>12</td>
              <td>24</td>
            </tr>
            <tr>
              <td>Invoice Payment</td>
              <td>1200</td>
              <td>2400</td>
              <td>4800</td>
            </tr>
          </tbody>
        </table>
      </div>


      {/* Section 3 */}

      <div className="section-3">

        <div className="info-header-3">
          <h3>Anti Fraud Detection (AFD) </h3>

        </div>

        <table className="bottom-border-table">
          <thead>
            <tr>
              <th>Activity Check</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Due Date Verification</td>
            <td><CheckCircleIcon className='checkIcon' />Due date is greater than the created date</td>
            </tr>
            <tr>
              <td>Valid Account For Transfer</td>
              <td><CheckCircleIcon className='checkIcon' />User is transferring money with a valid account number.</td>
            </tr>
            <tr>
              <td>High Increase vs. Last Invoice</td>
              <td><CheckCircleIcon className='checkIcon' />Total amount has not increased by 100% compared to the last invoice.</td>
            </tr>
            <tr>
              <td>High Decrease vs. Last Invoice</td>
              <td><ErrorIcon className='ErrorIcon' />Total amount has decreased by 100% compared to the last invoice. INV-2 having amount 1,697,528,872,788.00</td>
            </tr>
            <tr>
              <td>High Increase vs. Average</td>
              <td><CheckCircleIcon className='checkIcon' />Total amount has not increased by 100% compared to the average invoice.</td>
            </tr>
            <tr>
              <td>High Decrease vs. Average</td>
              <td><ErrorIcon className='ErrorIcon' />Total amount has decreased by 100% compared to the average invoice.</td>
            </tr>
            <tr>
              <td>Moderate Increase vs. Last Invoice</td>
              <td><CheckCircleIcon className='checkIcon' />Total amount has not increased by 30% compared to the last invoice.</td>
            </tr>
            <tr>
              <td>Moderate Increase vs. Average</td>
              <td><CheckCircleIcon className='checkIcon' />Total amount has not increased by 30% compared to the average invoice.</td>
            </tr>
            <tr>
              <td>Moderate Decrease vs. Average</td>
              <td><ErrorIcon className='YellowErrorIcon' />Total amount has decreased by 30% compared to the average invoice.</td>
            </tr>
            <tr>
              <td>Machine Learning Insights</td>
              <td><CheckCircleIcon className='checkIcon' />Via Machine Learning Prospective</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Section 4 */}


      <div className="section-4">

        <div className="info-header-4">
          <h3>Blockchain Validation </h3>

        </div>

        <div className="blockchain-offchain">
          <div className="column">
            <h3>Blockchain</h3>
            <h5>Invoice Id</h5>
            <p>INV-1</p>
            <h5>Due Date</h5>
            <p>26-12-2023</p>
            <h5>Creation Date</h5>
            <p>2-10-2023</p>
            <h5>Email</h5>
            <p>ahmed@gmail.com</p>
            <h5>Mobile Number</h5>
            <p>03453234341</p>
            <h5>Draft</h5>
            <p>No</p>
            <h5>Acknowledged</h5>
            <p>No</p>
            <h5>Rejected</h5>
            <p>No</p>
            <h5>Voided</h5>
            <p>N/A</p>
            <h5>Paid</h5>
            <p>Yes</p>
            <h5>Net Amount</h5>
            <p>68000</p>
            <h5>Currency</h5>
            <p>PKR</p>
            <h5>Payment Instrument</h5>
            <p>Cash</p>
            <h5>Payee Account</h5>
            <p>N/A</p>
          </div>

          <div className="icon-column">


            <p><SyncAltIcon className='arrowIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CheckCircleIcon className='checkIconColumn' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CheckCircleIcon className='checkIconColumn' /></p>
            <p><CheckCircleIcon className='checkIconColumn' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CheckCircleIcon className='checkIconColumn' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
            <p><CancelIcon className='closeIcon' /></p>
         

          </div>



          <div className="column">
            <h3>OffChain</h3>
            <h5>Invoice Id</h5>
            <p>INV-1</p>
            <h5>Due Date</h5>
            <p>26-12-2023</p>
            <h5>Creation Date</h5>
            <p>2-10-2023</p>
            <h5>Email</h5>
            <p>ahmed@gmail.com</p>
            <h5>Mobile Number</h5>
            <p>03453234341</p>
            <h5>Draft</h5>
            <p>No</p>
            <h5>Acknowledged</h5>
            <p>No</p>
            <h5>Rejected</h5>
            <p>No</p>
            <h5>Voided</h5>
            <p>N/A</p>
            <h5>Paid</h5>
            <p>Yes</p>
            <h5>Net Amount</h5>
            <p>68000</p>
            <h5>Currency</h5>
            <p>PKR</p>
            <h5>Payment Instrument</h5>
            <p>Cash</p>
            <h5>Payee Account</h5>
            <p>N/A</p>
          

          </div>
        </div>

      </div>

    </div>
      
   
  )
}

export default PdfDocument
