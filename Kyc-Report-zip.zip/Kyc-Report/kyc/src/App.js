
import { PDFViewer, PDFDownloadLink } from "@react-pdf/renderer";
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import { StyleSheet} from "@react-pdf/renderer";
import { Document} from "@react-pdf/renderer";
import Pdf from "./Pdf";





const styles = StyleSheet.create({
  page: {
    backgroundColor: "#d11fb6",
    color: "white",
  },
  section: {
    margin: 10,
    padding: 10,
  },
  viewer: {
    width: window.innerWidth, //the pdf viewer will take up all of the width and height
    height: window.innerHeight,
  },
});



function App() {

  // const invoice={
  //   invoiceNo:'A',
  //   id:'inv-1',

  // }
   

  return (

    
    <div className="container">

    <PDFViewer style={styles.viewer}>
    {/* Start of the document*/}
    <Document>
      {/*render a single page*/}

      <Pdf />
    </Document>
  </PDFViewer>

    <div className="download-content">
    <PDFDownloadLink document={<Pdf />} fileName="Download.pdf">
        {({  loading }) =>
          loading ? "Download..." : 
          <ArrowDownwardIcon />
        }

      </PDFDownloadLink>
    </div>

   
      </div>
  );
}

export default App;
