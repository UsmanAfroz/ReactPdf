import React from 'react'
import { Page, Text, View, Document, Font, Image, StyleSheet } from "@react-pdf/renderer";

import invoiceMate from "./invoiceMate.png";
import QR from "./QR.png"
import twoArrow from "./twoArrow.png";
import correct from "./correct.png";
import errorIcon from "./errorIcon.png";
import invalidIcon from "./invalidIcon.png";
import MyCustomFont from '../src/Fonts/MavenPro-Bold.ttf';
import MyCustomFont2 from '../src/Fonts/MavenPro-Regular.ttf';

Font.register({
  family: 'Maven Pro',
  src: MyCustomFont,
  fontWeight: 'bold',
  fontStyle: 'normal'
});

Font.register({
  family: 'Maven Pro',
  src: MyCustomFont2,
  fontWeight: 'normal',
  fontStyle: 'normal'
});

function Pdf() {

  const styles = StyleSheet.create({


    pageNumber: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      width: '100%',
      marginTop: 10,

    },
    privateImg: {
      fontSize: 10,
      color: 'red',
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 250
    },

    pageStyleContainer: {
      alignItems: 'flex-end', // Align to the right (flex end)
    },

    pageStyle: {
      fontSize: 9,
      marginRight: 4
    },

    invoicelogo: {
      height: 27,
    },

    logoContainer: {
      marginLeft: 14,
    },
    kycHeader: {
      backgroundColor: '#f2e4fd', // Light background color
      flexDirection: 'row',
      padding: 20,
      width: '100%',


    },
    kycHeader3: {
      backgroundColor: '#f2e4fd', // Light background color
      flexDirection: 'row',
      padding: 13,
      width: '100%',


    },
    kycReport: {
      flex: 2,
      justifyContent: 'center',
      alignItems: 'center',
      fontSize: 23,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
    
    },

    kyiInfo: {
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
      fontSize: 8,
      marginTop: 4
    },
    dateCreated: {
      flex: 1,
      alignItems: 'flex-end',
      fontSize: 12,
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
    },

    infoContainer: {
      marginTop: 40,
      padding: 13,
      borderColor: 'gray',
      marginBottom: 90,
      borderRadius: '5',
    },

    infoHeader1: {
      color: '#595959',
      fontSize: 18,

      fontFamily: 'Maven Pro',
      fontWeight: 'bold',

    },
    topSection: {

      flexDirection: 'row',
      width: '100%',


    },
    invoiceDetails: {
      marginTop: '10',
      marginLeft: 17,
      width: '80%',
    },
    itemsH6: {
      fontSize: '14',
      marginTop: 5,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      fontStyle: 'normal',
      
    },
    itemsP: {
      fontSize: '11',
      // fontWeight: 400,
      marginTop: 3,
      color: 'gray',
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',

    },

    qrImg: {
      height: '125',
      color: 'blue'
    },

    infoPara: {
      flexDirection: 'row',
      width: '100%',
      marginTop: 30,
    },

    senderHeading: {

      color: '#595959',
      fontSize: 18,


      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      marginBottom: 12,
    },
    receiverHeading: {
      color: '#595959',

      fontSize: 18,
      marginBottom: 12,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
    },
    senderInfo: {
      width: '50%',
      marginRight: 10,

    },
    receiverInfo: {
      width: '50%',

    },
    infoItem: {

      marginTop: 14,
      marginLeft: 17,

    },
    label: {
      fontSize: 14,
      marginBottom: 2,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      fontStyle: 'normal'

    },
    value: {
      fontSize: 11,
      color: 'gray',
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
    },



    // Section 2

    section2: {
      marginTop: 8,
      width: '100%',
      padding: 13,

    },
    infoHeader2: {
      color: '#595959',
      fontSize: 18,

      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      marginTop: 5
    },


    table: {
      width: '100%',
      // flexDirection: 'row',
      // display: 'flex',
      marginTop: 5,
      textAlign: 'left',

    },

    tableCell: {
      flex: 1,
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
      fontSize: 10,

      marginLeft: 5
    },
    headerCell: {
      flex: 1,
      fontFamily: 'Maven Pro',
      fontStyle: 'normal',
      fontWeight: 'bold',
      fontSize: 12,
      // padding: 8,
      alignItems: 'flex-start',


    },


    /* Section 3 */
    section3: {

      width: '100%',
      padding: 13,
      marginBottom: 6,
      marginTop: 5,
    },
    infoHeader3: {

      color: '#595959',
      fontSize: 18,

      fontFamily: 'Maven Pro',
      fontWeight: 'bold',

    },

    row: {
      flexDirection: 'row',
      borderBottomColor: '#D3D3D3',
      borderBottom: 1,
      borderBottomWidth: 0.7,
      padding: 13,
      // paddingVertical: 3,
    },
    cell: {
      flex: 1,


    },
    headerFont: {
      fontSize: 10,

      fontFamily: 'Maven Pro',
      fontWeight: 'bold',

    },
    activityCheckCell: {
      flex: 1.3,
      fontSize: 9,
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
      borderBottomColor: '#D3D3D3',
    },
    descriptionCell: {
      flex: 3,
      fontSize: 9,
      fontFamily: 'Maven Pro',
      fontWeight: 'normal',
      borderBottomColor: '#D3D3D3',

    },

    /* section 4*/

    section4: {

      padding: 13,
      width: '100%',
      marginTop: 27,

    },
    infoHeader4: {
      color: '#595959',
      fontSize: 17,

      fontFamily: 'Maven Pro',
      fontWeight: 'bold',

    },

    blockchainOffchain: {
      flexDirection: 'row',
      marginTop: 19,
    },
    column: {
      width: '46%',
      textAlign: 'center',
      justifyContent: 'center',

    },
    columnH3: {
      marginTop: 9,
      fontSize: 14,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      fontStyle: 'normal',

    },
    columnH5: {
      marginTop: 12,
      fontSize: 10,
      // marginBottom: 4,
      fontFamily: 'Maven Pro',
      fontWeight: 'bold',
      fontStyle: 'normal'
    },

    columnP: {
      fontSize: 9,
      //  borderBottom: '1px solid rgb(250, 242, 242)',
      marginTop: 7,
      fontFamily: 'Maven Pro',
      fontStyle: 'normal',
      borderBottomWidth: 1.5,
      borderBottomColor: '#F5F5F5'
    },

    iconColumn: {
      width: '2%',
      marginTop: 7

    },

    twoArrowIcon: {
      fontSize: 8
    },

    iconText: {

      fontSize: '8',
      marginTop: 33,
    }
 ,
    page: {
      flexDirection: 'column',
      backgroundColor: 'black',
      flex: 1,
    },
    background: {

      minWidth: '100%',
      minHeight: '100%',
    },

    backgroundImg:{
      height:'20',
      marginTop:20,
    },
    content: {
      padding: 30,
    },
    title: {
      fontSize: 20,
      marginBottom: 10,
    },

  });

  return (

    <Document>

      <Page size="A4">

    
        <View style={styles.kycHeader}>

          <View style={styles.logoContainer}>
            <Image src={invoiceMate} style={styles.invoicelogo} />
          </View>

          <View style={styles.kycReport}>
            <Text>KYI Report </Text>
            <Text style={styles.kyiInfo}> (Know Your Information) </Text>
          </View>


          <View style={styles.dateCreated}>

            <Text>INV-001 </Text>
            <Text>06-03-2023</Text>

          </View>

        </View>

       

        <View style={styles.infoContainer}>

          <View style={styles.infoHeader1}>
            <Text>1. Invoice Information</Text>
          </View>
          <View style={styles.topSection}>
            <View style={styles.invoiceDetails}>
              <View style={styles.items}>
                <Text style={styles.itemsH6}>inv-001</Text>
                <Text style={styles.itemsP}>inv</Text>
              </View>
              <View style={styles.items}>
                <Text style={styles.itemsH6}>Status</Text>
                <Text style={styles.itemsP}>Paid</Text>
              </View>
              <View style={styles.items}>
                <Text style={styles.itemsH6}>Acknowledged</Text>
                <Text style={styles.itemsP}>No</Text>
              </View>
              <View style={styles.items}>
                <Text style={styles.itemsH6}>Payment Type</Text>
                <Text style={styles.itemsP}>Cash</Text>
              </View>
              <View style={styles.items}>
                <Text style={styles.itemsH6}>Invoice Amount</Text>
                <Text style={styles.itemsP}>67800</Text>
              </View>
            </View>
            <View style={styles.qrImg}>
              <Image src={QR} style={styles.qrImg} />
            </View>
          </View>



          <View style={styles.infoPara}>


            <View style={styles.receiverInfo}>


              <View style={styles.infoItem}>
                <View style={styles.senderHeading}>
                  <Text >Sender Information</Text>
                </View>
                <Text style={styles.label}>Name</Text>
                <Text style={styles.value}>Ahmed </Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Email</Text>
                <Text style={styles.value}>im2021@mailinator.com</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Mobile Number</Text>
                <Text style={styles.value}>+924981472897</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Business Name</Text>
                <Text style={styles.value}>as</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Profession</Text>
                <Text style={styles.value}>Entertainment</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>City</Text>
                <Text style={styles.value}>Faisalabad</Text>
              </View>
            </View>


            <View style={styles.receiverInfo}>
              <View style={styles.infoItem}>
                <View style={styles.receiverHeading}>
                  <Text >Receiver Information</Text>
                </View>
                <Text style={styles.label}>Name</Text>
                <Text style={styles.value}>Bilal</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Email</Text>
                <Text style={styles.value}>im2021@mailinator.com</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Mobile Number</Text>
                <Text style={styles.value}>+971327362736723</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Business Name</Text>
                <Text style={styles.value}>jahsajs</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>Profession</Text>
                <Text style={styles.value}>Education</Text>
              </View>
              <View style={styles.infoItem}>
                <Text style={styles.label}>City</Text>
                <Text style={styles.value}>N/A</Text>
              </View>

            </View>
          </View>
        </View>


  
        <View style={styles.pageNumber}>
          <Text style={styles.privateImg}>Private and Confidential</Text>
          <View style={styles.pageStyleContainer}>
            <Text style={styles.pageStyle}>3</Text>
          </View>
        </View>



        <View style={styles.kycHeader}>

          <View style={styles.logoContainer}>
            <Image src={invoiceMate} style={styles.invoicelogo} />
          </View>

          <View style={styles.kycReport}>
            <Text>KYI Report </Text>
            <Text style={styles.kyiInfo}> (Know Your Information) </Text>
          </View>




          <View style={styles.dateCreated}>

            <Text>INV-001 </Text>
            <Text>06-03-2023</Text>

          </View>

        </View>

        {/* Section 2 */}

        <View>
          {/* Table Header */}
          <View style={styles.section2}>

            <View style={styles.infoHeader2}>
              <Text>2. Business Relation</Text>
            </View>
            <View style={styles.table}>
              <View style={styles.row}>
                <View style={styles.headerCell}>
                  <Text>Series</Text>
                </View>
                <View style={styles.headerCell}>
                  <Text>3 Months</Text>
                </View>
                <View style={styles.headerCell}>
                  <Text>6 Months</Text>
                </View>
                <View style={styles.headerCell}>
                  <Text>12 Months</Text>
                </View>
              </View>
              <View style={styles.row}>
                <View style={styles.tableCell}>
                  <Text>Invoice Amount</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>100</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>200</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>400</Text>
                </View>
              </View>
              <View style={styles.row}>
                <View style={styles.tableCell}>
                  <Text>Invoice Count</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>6</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>12</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>24</Text>
                </View>
              </View>
              <View style={styles.row}>
                <View style={styles.tableCell}>
                  <Text>Invoice Payment</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>1200</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>2400</Text>
                </View>
                <View style={styles.tableCell}>
                  <Text>4800</Text>
                </View>
              </View>
            </View>
          </View>


        </View>




        {/* Section 3 */}

        <View style={styles.section3}>

          <View style={styles.infoHeader3}>
            <Text> Fraud Detection System (FDS)</Text>
          </View>
          <View style={styles.table}>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text style={styles.headerFont}>Activity Check</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text style={styles.headerFont}>Description</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Due Date Verification</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Due date is greater than the created date</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Valid Account For Transfer</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> User is transferring money with a valid account number.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>High Increase vs. Last Invoice</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Total amount has not increased by 100% compared to the last invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>High Decrease vs. Last Invoice</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Total amount has decreased by 100% compared to the last invoice. INV-2 having amount 1,697,528,872,788.00</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>High Increase vs. Average</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Total amount has not increased by 100% compared to the average invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>High Decrease vs. Average</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={invalidIcon} /> Total amount has decreased by 100% compared to the average invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Moderate Increase vs. Last Invoice</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={invalidIcon} /> Total amount has not increased by 30% compared to the last invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Moderate Increase vs. Average</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Total amount has not increased by 30% compared to the average invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Moderate Decrease vs. Average</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={correct} /> Total amount has decreased by 30% compared to the average invoice.</Text>
              </View>
            </View>
            <View style={styles.row}>
              <View style={styles.activityCheckCell}>
                <Text>Machine Learning Insights</Text>
              </View>
              <View style={styles.descriptionCell}>
                <Text> <Image src={invalidIcon} /> Via Machine Learning Prospective</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.pageNumber}>
          <View style={styles.privateContainer}>
            <Text style={styles.privateImg}>Private and Confidential</Text>
          </View>
          <View style={styles.pageStyleContainer}>
            <Text style={styles.pageStyle}>2</Text>
          </View>
        </View>


        <View style={styles.kycHeader3}>

          <View style={styles.logoContainer}>
            <Image src={invoiceMate} style={styles.invoicelogo} />
          </View>

          <View style={styles.kycReport}>
            <Text>KYI Report </Text>
            <Text style={styles.kyiInfo}> (Know Your Information) </Text>
          </View>

          <View style={styles.dateCreated}>

            <Text>INV-001 </Text>
            <Text>06-03-2023</Text>

          </View>

        </View>


        {/*Section 4*/}

        <View style={styles.section4}>

          <View style={styles.infoHeader4}>
            <Text>3. Blockchain Validation</Text>
          </View>
          <View style={styles.blockchainOffchain}>
            <View style={styles.column}>
              <Text style={styles.columnH3}>Blockchain</Text>
              <Text style={styles.columnH5}>Invoice Id</Text>
              <Text style={styles.columnP}>INV-191</Text>
              <Text style={styles.columnH5}>Due Date</Text>
              <Text style={styles.columnP}>28-2-2024</Text>
              <Text style={styles.columnH5}>Creation Date</Text>
              <Text style={styles.columnP}>23-12-2023</Text>
              <Text style={styles.columnH5}>Email</Text>
              <Text style={styles.columnP}>test@gmail.com</Text>
              <Text style={styles.columnH5}>Mobile Number</Text>
              <Text style={styles.columnP}>0301-3002983</Text>
              <Text style={styles.columnH5}>Draft</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Acknowledged</Text>
              <Text style={styles.columnP}>Yes</Text>
              <Text style={styles.columnH5}>Rejected</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Voided</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Paid</Text>
              <Text style={styles.columnP}>Yes</Text>
              <Text style={styles.columnH5}>Net Amount</Text>
              <Text style={styles.columnP}>68000</Text>
              <Text style={styles.columnH5}>Currency</Text>
              <Text style={styles.columnP}>PKR</Text>
              <Text style={styles.columnH5}>Payment Instrument</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Payee Account</Text>
              <Text style={styles.columnP}>N/A</Text>
            </View>


            <View style={styles.iconColumn}>
              <Text style={styles.twoArrowIcon}><Image src={twoArrow} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={correct} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={correct} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={correct} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={correct} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>
              <Text style={styles.iconText}><Image src={errorIcon} style={styles.columnImage} /></Text>

            </View>


            <View style={styles.column}>
              <Text style={styles.columnH3}>Off-Chain</Text>
              <Text style={styles.columnH5}>Invoice Id</Text>
              <Text style={styles.columnP}>INV-191</Text>
              <Text style={styles.columnH5}>Due Date</Text>
              <Text style={styles.columnP}>28-2-2024</Text>
              <Text style={styles.columnH5}>Creation Date</Text>
              <Text style={styles.columnP}>23-12-2023</Text>
              <Text style={styles.columnH5}>Email</Text>
              <Text style={styles.columnP}>test@gmail.com</Text>
              <Text style={styles.columnH5}>Mobile Number</Text>
              <Text style={styles.columnP}>0301-3002983</Text>
              <Text style={styles.columnH5}>Draft</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Acknowledged</Text>
              <Text style={styles.columnP}>Yes</Text>
              <Text style={styles.columnH5}>Rejected</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Voided</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Paid</Text>
              <Text style={styles.columnP}>Yes</Text>
              <Text style={styles.columnH5}>Net Amount</Text>
              <Text style={styles.columnP}>68000</Text>
              <Text style={styles.columnH5}>Currency</Text>
              <Text style={styles.columnP}>PKR</Text>
              <Text style={styles.columnH5}>Payment Instrument</Text>
              <Text style={styles.columnP}>No</Text>
              <Text style={styles.columnH5}>Payee Account</Text>
              <Text style={styles.columnP}>N/A</Text>
            </View>
          </View>
        </View>



        <View style={styles.pageNumber}>
          <Text style={styles.privateImg}>Private and Confidential</Text>
          <View style={styles.pageStyleContainer}>
            <Text style={styles.pageStyle}>3</Text>
          </View>
        </View>


      </Page>
    </Document>

  )
}

export default Pdf
